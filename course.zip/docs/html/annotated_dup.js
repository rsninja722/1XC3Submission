var annotated_dup =
[
    [ "_course", "struct__course.html", null ],
    [ "_student", "struct__student.html", null ]
];