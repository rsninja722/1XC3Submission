/**
 * handels the logic of creating, modifying, and printing students
 * 
 * @file student.c
 * @author TA's
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * adds a grade to a student's list of grades
 * 
 * @param student pointer to a student to add grade
 * @param grade grade to add
 */
void add_grade(Student* student, double grade)
{
    // increase grades count
    student->num_grades++;
    // allocate memory for a new if this is the first grade, otherwise, increase the size of the existing grades list 
    if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
    else 
    {
        student->grades = 
        realloc(student->grades, sizeof(double) * student->num_grades);
    }
    // add the new grade to the list
    student->grades[student->num_grades - 1] = grade;
}

/**
 * calculates the average of all of a students grades
 * 
 * @param student a student to calculate average for
 * @return a double representing the average grade
 */
double average(Student* student)
{
    // return 0 if there are no grades
    if (student->num_grades == 0) return 0;

    // otherwise calculate and return the average
    double total = 0;
    for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
    return total / ((double) student->num_grades);
}

/**
 * prints the information about a student to the console
 * 
 * @param student student to print info for
 */
void print_student(Student* student)
{
    printf("Name: %s %s\n", student->first_name, student->last_name);
    printf("ID: %s\n", student->id);
    printf("Grades: ");
    for (int i = 0; i < student->num_grades; i++) 
        printf("%.2f ", student->grades[i]);
    printf("\n");
    printf("Average: %.2f\n\n", average(student));
}

/**
 * creates a student with a random name, id, and set of grades 
 * 
 * @param grades how many grades the student should have
 * @return Student* a pointer to the new random student
 */
Student* generate_random_student(int grades)
{
    char first_names[][24] = 
        {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
        "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
        "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

    char last_names[][24] = 
    {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
        "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
        "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
    
    // allocate memory for the student
    Student *new_student = calloc(1, sizeof(Student));

    // set the first and last name
    strcpy(new_student->first_name, first_names[rand() % 24]);
    strcpy(new_student->last_name, last_names[rand() % 24]);

    // set a random id
    for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
    new_student->id[10] = '\0';

    // set random grades
    for (int i = 0; i < grades; i++) 
    {
        add_grade(new_student, (double) (25 + (rand() % 75)));
    }

    // return point to the student
    return new_student;
}