var searchData=
[
  ['top_5fstudent_0',['top_student',['../course_8c.html#ac1d82150824c7ecd43bab36fb83cd779',1,'course.c']]]
];
