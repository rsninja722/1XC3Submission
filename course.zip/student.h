/**
 * Student type stores a student with a name, id, and list of grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;
/**
 * adds a grade to a student's list of grades
 * 
 * @param student pointer to a student to add grade
 * @param grade grade to add
 */
void add_grade(Student *student, double grade);
/**
 * calculates the average of all of a students grades
 * 
 * @param student a student to calculate average for
 * @return a double representing the average grade
 */
double average(Student *student);
/**
 * prints the information about a student to the console
 * 
 * @param student student to print info for
 */
void print_student(Student *student);
/**
 * creates a student with a random name, id, and set of grades 
 * 
 * @param grades how many grades the student should have
 * @return Student* a pointer to the new random student
 */
Student* generate_random_student(int grades); 
