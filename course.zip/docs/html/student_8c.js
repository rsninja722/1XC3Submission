var student_8c =
[
    [ "add_grade", "student_8c.html#a1ee4302d01d8908db57e238f5f9dd9f5", null ],
    [ "average", "student_8c.html#a3efb000301e4e0c8e68930bc93e0958e", null ],
    [ "generate_random_student", "student_8c.html#ad0f523c2c17c9b40389cd8031052fc85", null ],
    [ "print_student", "student_8c.html#a4d964bf73eb1b291728dbf7380a9e6ab", null ]
];