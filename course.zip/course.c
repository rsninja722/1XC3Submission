/**
 * handels the logic of creating and modifying courses as well as accessing and printing their information
 * 
 * @file course.c
 * @author TA's
 * @brief 
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * adds a student to a course
 * 
 * @param course pointer to a course to add the student to
 * @param student point to the student to enroll
 */
void enroll_student(Course *course, Student *student)
{
    // incrase count of students
    course->total_students++;
    // allocate memory for the array of students if this is the first student, allocate more memory if the student array is already allocated
    if (course->total_students == 1) 
    {
        course->students = calloc(1, sizeof(Student));
    }
    else 
    {
        course->students = 
        realloc(course->students, course->total_students * sizeof(Student)); 
    }
    // add the student to the course
    course->students[course->total_students - 1] = *student;
}

/**
 * prints info about a corse and all the students in it
 * 
 * @param course course to print info about
 */
void print_course(Course* course)
{
    // print course info
    printf("Name: %s\n", course->name);
    printf("Code: %s\n", course->code);
    printf("Total students: %d\n\n", course->total_students);
    printf("****************************************\n\n");
    // print students
    for (int i = 0; i < course->total_students; i++) 
        print_student(&course->students[i]);
}

/**
 * find and return the top student for a given course
 * 
 * @param course pointer to the course to find the top student for
 * @return Student* pointer to the top student
 */
Student* top_student(Course* course)
{
    // return null if there are no students
    if (course->total_students == 0) return NULL;
    
    // average for current student
    double student_average = 0;
    // best average so far
    double max_average = average(&course->students[0]);
    // list of students
    Student *student = &course->students[0];
    
    // go through all students and find which one has the highest average
    for (int i = 1; i < course->total_students; i++)
    {
        student_average = average(&course->students[i]);
        if (student_average > max_average) 
        {
        max_average = student_average;
        student = &course->students[i];
        }   
    }

    // return the student with the highest average
    return student;
}

/**
 * calculates whether or not the student is passing the course
 * 
 * @param course course to find passing students for
 * @param total_passing pointer to an int that will get changed to the amount of students that passed
 * @return Student* array of students that passesd
 */
Student *passing(Course* course, int *total_passing)
{
    // number of passing students 
    int count = 0;
    // array of passing students
    Student *passing = NULL;
    
    // set count to the amount of students with an average at or above 50%
    for (int i = 0; i < course->total_students; i++) 
        if (average(&course->students[i]) >= 50) count++;
    
    // allocate memory for an array of pointers to students that passed
    passing = calloc(count, sizeof(Student));

    // add all students with an average at or above 50% to the array of passing students
    int j = 0;
    for (int i = 0; i < course->total_students; i++)
    {
        if (average(&course->students[i]) >= 50)
        {
        passing[j] = course->students[i];
        j++; 
        }
    }

    // set the integer passed into the function to the amount of passing students
    *total_passing = count;

    // return the array of passing students
    return passing;
}