#include "student.h"
#include <stdbool.h>

/**
 * Course type stores a course with a name, course code, and list of students
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * adds a student to a course
 * 
 * @param course pointer to a course to add the student to
 * @param student point to the student to enroll
 */
void enroll_student(Course *course, Student *student);
/**
 * prints info about a corse and all the students in it
 * 
 * @param course course to print info about
 */
void print_course(Course *course);
/**
 * find and return the top student for a given course
 * 
 * @param course pointer to the course to find the top student for
 * @return Student* pointer to the top student
 */
Student *top_student(Course* course);
/**
 * calculates whether or not the student is passing the course
 * 
 * @param course course to find passing students for
 * @param total_passing pointer to an int that will get changed to the amount of students that passed
 * @return Student* array of students that passesd
 */
Student *passing(Course* course, int *total_passing);


